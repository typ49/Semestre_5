"use strict";

// Zone d'affichage à l'écran
const WIDTH = 800;
const HEIGHT = 512;


/**
 *  FLAPPY BIDS - version 2023
 */
document.addEventListener("DOMContentLoaded", function() {

    /** Récupération des informations liées au canvas */
    const canvas = document.getElementById("cvs");
    const ctx = canvas.getContext("2d"); 

    /** Dernière mise à jour de l'affichage */
    let last = Date.now();

    /** Boucle de jeu */
    (function loop() {
        // précalcul de la prochaine image
        requestAnimationFrame(loop);
        // mise à jour du modèle de données
        let now = Date.now();
        // TODO :
        // - mise à jour de l'état du jeu (update)
        // - affichage du nouvel état (render)
        last = now;
    })();

});