#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

#include "grid.h"

/**
 * Tire et renvoie un entier pseudo-aléatoire entre min et max bornes incluses.
 *
 * @param min valeur minimale de l'entier
 * @param max valeur maximale de l'entier
 */
int random_int(int min, int max){
    return (int)((rand()/(RAND_MAX+1.0))*(max-min+1)+min);
}

/**
 * Affiche l'usage du programme sur stderr.
 *
 * @param cmd paramètre argv[0] reçu via la ligne de commande
 */
void print_usage(const char *cmd){
    fprintf(stderr, "Usage : %s NB_ATTEMPTS BOAT_LENGTH...\n", cmd);
}

int main(int argc, char *argv[]){
    if (argc < 3){
        print_usage(argv[0]);
        return 1;
    }

    const int grid_size = 10;

    // tableau avec les longueurs des bateaux à placer
    size_t *boat_lengths = calloc(argc - 2, sizeof(size_t));
    for (int i = 2; i < argc; ++i){
        int l = atoi(argv[i]);
        if (l < 1 || l > grid_size){
            free(boat_lengths);
            boat_lengths = NULL;
            fprintf(stderr, "All boat lengths must be greater than or equal to 1 and less than or equal to %d.\n", grid_size);
            print_usage(argv[0]);
            return 3;
        }
        boat_lengths[i - 2] = l;

    }

    struct grid g;
    grid_create(&g, grid_size);

    // A compléter

    free(boat_lengths);
    boat_lengths = NULL;

    grid_destroy(&g);

    return 0;
}
