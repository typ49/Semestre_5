#include <stdio.h>
#include <time.h>
#include <stdlib.h>

/* limites pour les opérandes */
#define MIN 0
#define MAX 100

/* constantes pour les opérateurs */
#define ADD 1
#define SUB ADD+1
#define MULT SUB+1
#define DIV MULT+1

/**
 * Structure d'une opération 
 */
 struct operation {
    int oprt;   /* opérateur binaire : + -> 1, - -> 2, * -> 3, / -> 4  */
    int oprd;   /* deuxième opérande, de droite */
 };
 
 
/**
 * Tire et renvoie un entier pseudo-aléatoire entre min et max bornes incluses.
 *
 * @param min valeur minimale de l'entier
 * @param max valeur maximale de l'entier
 */
int gen_int_rand(int min, int max) {
    return (int)((rand()/(RAND_MAX+1.0))*(max-min+1)+min);
}

/**
 * Génère aléatoirement une opération (opérateur et opérande de droite).
 *
 * @param p_op adresse d'une opération
 */
void gen_op(struct operation *p_op){
    p_op->oprt = gen_int_rand(ADD,DIV);
    p_op->oprd = gen_int_rand(MIN, MAX);
}

/**
 * Affiche une opération (opérateur et opérande de droite).
 *
 * @param p_op adresse d'une opération
 */
void aff_op(const struct operation *p_op){
    switch (p_op->oprt) {
    	case ADD : printf("+"); break;
    	case SUB : printf("-"); break;
    	case MULT : printf("*"); break;
    	case DIV : printf("/"); break;
    }
    printf(" ");
    printf("%d", p_op->oprd);
    printf(" ");   
}

int main(int argc, char *argv[]){
    srand(time(NULL));
}
