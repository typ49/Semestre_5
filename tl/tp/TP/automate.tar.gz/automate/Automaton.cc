#include "Automaton.h"


namespace fa {

  Automaton::Automaton() {
  }

  bool Automaton::isValid() const {
    return true;
  }


}

