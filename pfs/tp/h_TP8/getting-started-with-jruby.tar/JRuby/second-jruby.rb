#  ============================================================================
#  Example of importing a Java class suitable for Ruby ---
#  Seminex, 15th May 2014

include Java

$a = Java::jrubytrying.Imported_By_JRuby.make

p $a
