package jrubytrying ;

public class Animal {
    //
    private String name ;
    //
    public Animal(String name_0) { name = name_0 ; }
    //
    public String get_name() { return name ; }
    //
    public void eat() { System.out.println("Miam-miam bouffe-bouffe !") ; }
    //
}
